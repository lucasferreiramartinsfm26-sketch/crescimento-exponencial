# Crescimento Exponencial

Aplicativo web responsivo/PWA para conectar pessoas e empresas.

## Funcionalidades incluídas
- Página inicial responsiva em português.
- Cadastro e login com e-mail e senha via Supabase Auth.
- Botões de login Google e Apple (dependem da configuração OAuth dos provedores no Supabase).
- Envio de cadastro de empresa com status `pending`.
- Listagem das empresas aprovadas, das próprias empresas e visão administrativa.
- Aprovação/recusa de empresas no painel administrativo.
- Proteção de dados por Row Level Security (RLS).
- Preparação para instalação como PWA.

## 1. Configurar o banco Supabase
1. Abra seu projeto em https://supabase.com/dashboard.
2. Entre em **SQL Editor** e crie uma nova query.
3. Abra `supabase/schema.sql`, copie todo o conteúdo e execute.
4. Em **Authentication > URL Configuration**, adicione a URL local `http://localhost:5173` e, após publicar, o domínio de produção.

## 2. Configurar o aplicativo
1. Instale Node.js LTS em um computador ou use um ambiente de desenvolvimento online compatível.
2. Copie `.env.example` para `.env`.
3. No Supabase, abra **Project Settings > API** e copie Project URL e a chave `anon`/`publishable` para as variáveis:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4. Nunca use a chave `service_role` no navegador.
5. Execute `npm install`, depois `npm run dev`.

## 3. Criar seu administrador
1. Crie sua conta no aplicativo usando o e-mail que será do proprietário.
2. No Supabase SQL Editor, substitua `SEU_EMAIL` no bloco comentado ao final de `supabase/schema.sql` pelo e-mail exato da sua conta e execute o bloco.
3. Saia e entre novamente no aplicativo. O painel administrativo será liberado.

Não existe cadastro público de administrador. A atribuição da função é feita diretamente pelo proprietário no Supabase.

## 4. Publicar gratuitamente
1. Envie todos os arquivos deste projeto para o repositório GitHub `crescimento-exponencial`.
2. Na Vercel, importe o repositório.
3. Use `npm run build` como comando de build e `dist` como diretório de saída.
4. Configure na Vercel as mesmas duas variáveis de ambiente do arquivo `.env`.
5. Adicione o domínio publicado em **Supabase > Authentication > URL Configuration**.

## 5. Google e Apple
Os botões já estão preparados no frontend. Para funcionarem, configure cada provedor em **Supabase > Authentication > Providers**, incluindo as credenciais OAuth exigidas pelo Google ou Apple. Até essa configuração, use e-mail e senha.

## Limites e estado
Este pacote é uma base funcional de aplicação, mas não está conectado à sua conta Supabase nem publicado. A ativação depende das etapas de configuração acima, das credenciais e da publicação. Planos gratuitos têm limites e condições próprios.
