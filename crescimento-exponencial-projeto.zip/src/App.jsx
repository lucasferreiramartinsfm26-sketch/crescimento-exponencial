import { useEffect, useState } from "react";
import { Link, Navigate, Route, Routes, useNavigate } from "react-router-dom";
import { ArrowUpRight, Building2, Check, CircleHelp, ClipboardList, LogOut, Menu, ShieldCheck, TrendingUp, Users, X } from "lucide-react";
import { isSupabaseConfigured, supabase } from "./lib/supabase";

function Brand() {
  return <Link className="brand" to="/"><span className="brand-mark"><TrendingUp size={23}/></span><span>Crescimento <b>Exponencial</b></span></Link>;
}

function Shell({ children, session, onSignOut }) {
  return <div className="app-shell">
    <header className="topbar"><Brand/><nav><a href="#como-funciona">Como funciona</a><a href="#empresas">Empresas</a>{session ? <button className="btn btn-outline" onClick={onSignOut}><LogOut size={16}/> Sair</button> : <Link className="btn btn-primary" to="/entrar">Entrar</Link>}</nav></header>
    <main>{children}</main>
    <footer><Brand/><span>© {new Date().getFullYear()} Crescimento Exponencial</span></footer>
  </div>;
}

function Auth({ mode, onAuth }) {
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [name,setName]=useState("");
  const [busy,setBusy]=useState(false); const [error,setError]=useState(""); const [message,setMessage]=useState("");
  const signUp = mode === "cadastro";
  async function submit(e) {
    e.preventDefault(); setBusy(true); setError(""); setMessage("");
    try {
      if (!isSupabaseConfigured) throw new Error("O Supabase ainda não foi configurado. Preencha as variáveis de ambiente indicadas no README.");
      if (signUp) {
        const {data,error}=await supabase.auth.signUp({email,password,options:{data:{full_name:name}}});
        if(error) throw error;
        if(data.session) onAuth(data.session);
        else setMessage("Conta criada. Verifique seu e-mail para confirmar o cadastro antes de entrar.");
      } else {
        const {data,error}=await supabase.auth.signInWithPassword({email,password});
        if(error) throw error; onAuth(data.session);
      }
    } catch(err) { setError(err.message || "Não foi possível concluir."); }
    finally { setBusy(false); }
  }
  async function oauth(provider) {
    setError("");
    if(!isSupabaseConfigured){setError("Configure o Supabase antes de ativar este acesso.");return;}
    const {error}=await supabase.auth.signInWithOAuth({provider,options:{redirectTo:window.location.origin}});
    if(error)setError(error.message);
  }
  return <section className="auth-wrap"><div className="auth-card"><div className="eyebrow">SUA JORNADA COMEÇA AQUI</div><h1>{signUp?"Crie sua conta":"Bem-vindo de volta"}</h1><p className="muted">{signUp?"Cadastre-se para acessar oportunidades e empresas.":"Entre para continuar no Crescimento Exponencial."}</p>
    <form onSubmit={submit}>{signUp&&<label>Nome completo<input value={name} onChange={e=>setName(e.target.value)} required placeholder="Seu nome"/></label>}<label>E-mail<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required placeholder="voce@email.com"/></label><label>Senha<input type="password" minLength="6" value={password} onChange={e=>setPassword(e.target.value)} required placeholder="Mínimo de 6 caracteres"/></label><button className="btn btn-primary full" disabled={busy}>{busy?"Aguarde...":signUp?"Criar conta":"Entrar"}</button></form>
    <div className="separator">ou continue com</div><div className="oauth-row"><button className="btn btn-outline" onClick={()=>oauth("google")}>Google</button><button className="btn btn-outline" onClick={()=>oauth("apple")}>Apple</button></div>
    {error&&<p className="notice error">{error}</p>}{message&&<p className="notice success">{message}</p>}
    <p className="auth-switch">{signUp?"Já tem uma conta?":"Ainda não tem conta?"} <Link to={signUp?"/entrar":"/cadastro"}>{signUp?"Entrar":"Criar conta"}</Link></p>
  </div></section>;
}

function Dashboard({ session, isAdmin }) {
  const [companies,setCompanies]=useState([]); const [form,setForm]=useState({name:"",category:"",description:"",phone:"",city:"",state:""});
  const [error,setError]=useState(""); const [message,setMessage]=useState(""); const [loading,setLoading]=useState(false);
  async function load(){ if(!supabase)return; const {data,error}=await supabase.from("companies").select("*").order("created_at",{ascending:false}); if(error)setError(error.message); else setCompanies(data||[]); }
  useEffect(()=>{load();},[]);
  async function create(e){e.preventDefault();setLoading(true);setError("");setMessage("");const {error}=await supabase.from("companies").insert({...form,owner_id:session.user.id,status:"pending"});if(error)setError(error.message);else{setForm({name:"",category:"",description:"",phone:"",city:"",state:""});setMessage("Empresa enviada para análise. Ela ficará visível após aprovação.");load();}setLoading(false);}
  async function decide(id,status){setError("");const {error}=await supabase.from("companies").update({status}).eq("id",id);if(error)setError(error.message);else load();}
  return <section className="dashboard"><div className="dash-heading"><div><div className="eyebrow">ÁREA DO USUÁRIO</div><h1>Olá, {session.user.user_metadata?.full_name||session.user.email}</h1><p className="muted">Gerencie seus cadastros e acompanhe as empresas.</p></div><span className="status-pill"><span/> Conta conectada</span></div>
    {!isAdmin&&<div className="panel"><h2><Building2/> Cadastrar empresa</h2><p className="muted">Sua empresa será analisada antes de aparecer no diretório.</p><form className="form-grid" onSubmit={create}><label>Nome da empresa<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></label><label>Categoria<input value={form.category} onChange={e=>setForm({...form,category:e.target.value})} placeholder="Ex.: alimentação"/></label><label>Telefone/WhatsApp<input value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/></label><label>Cidade<input value={form.city} onChange={e=>setForm({...form,city:e.target.value})}/></label><label>Estado<input value={form.state} onChange={e=>setForm({...form,state:e.target.value})}/></label><label className="span-two">Descrição<textarea value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></label><div className="span-two"><button className="btn btn-primary" disabled={loading}>{loading?"Enviando...":"Enviar para aprovação"}</button></div></form></div>}
    <div className="panel" id="empresas"><h2>{isAdmin?<ShieldCheck/>:<ClipboardList/>}{isAdmin?" Administração de empresas":"Minhas empresas e diretório"}</h2>{error&&<p className="notice error">{error}</p>}{message&&<p className="notice success">{message}</p>}
      {companies.length===0?<p className="muted">Nenhuma empresa encontrada ainda.</p>:<div className="company-list">{companies.map(c=><article className="company-row" key={c.id}><div><b>{c.name}</b><p className="muted">{[c.category,c.city,c.state].filter(Boolean).join(" • ")}</p><span className={"tag "+c.status}>{c.status==="pending"?"Pendente":c.status==="approved"?"Aprovada":"Recusada"}</span></div>{isAdmin&&c.status==="pending"&&<div className="actions"><button className="btn btn-small btn-primary" onClick={()=>decide(c.id,"approved")}><Check size={15}/> Aprovar</button><button className="btn btn-small btn-outline" onClick={()=>decide(c.id,"rejected")}>Recusar</button></div>}</article>)}</div>}
    </div>
  </section>;
}

export default function App(){
  const [session,setSession]=useState(null); const [ready,setReady]=useState(!isSupabaseConfigured); const [isAdmin,setIsAdmin]=useState(false); const [mobileOpen,setMobileOpen]=useState(false);
  useEffect(()=>{if(!isSupabaseConfigured)return;supabase.auth.getSession().then(({data})=>{setSession(data.session);setReady(true);});const {data:{subscription}}=supabase.auth.onAuthStateChange((_event,s)=>setSession(s));return()=>subscription.unsubscribe();},[]);
  useEffect(()=>{async function check(){if(!session||!supabase){setIsAdmin(false);return;}const {data}=await supabase.rpc("is_admin");setIsAdmin(Boolean(data));}check();},[session]);
  async function signOut(){await supabase?.auth.signOut();setSession(null);}
  if(!ready)return <div className="loading">Carregando Crescimento Exponencial...</div>;
  return <Shell session={session} onSignOut={signOut}><Routes>
    <Route path="/" element={session?<Dashboard session={session} isAdmin={isAdmin}/>:<><section className="hero"><div className="hero-copy"><div className="eyebrow"><span className="dot"/> CONEXÕES QUE GERAM OPORTUNIDADES</div><h1>Seu próximo passo começa com <em>crescimento.</em></h1><p>Uma plataforma para aproximar pessoas e empresas, criar conexões e abrir caminhos para novas oportunidades.</p><div className="hero-actions"><Link className="btn btn-primary" to="/cadastro">Começar agora <ArrowUpRight size={18}/></Link><Link className="btn btn-outline" to="/entrar">Já tenho conta</Link></div><div className="hero-note"><ShieldCheck size={16}/> Empresas passam por aprovação antes de serem publicadas.</div></div><div className="hero-art"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="growth-card"><div className="growth-icon"><TrendingUp size={35}/></div><span>IDEIAS EM MOVIMENTO</span><strong>Cresça. Conecte. Evolua.</strong><div className="bars"><i/><i/><i/><i/><i/><i/><i/></div></div><div className="floating-chip chip-a"><Building2 size={17}/> Empresas</div><div className="floating-chip chip-b"><Users size={17}/> Pessoas</div></div></section><section className="features" id="como-funciona"><div className="section-title"><div className="eyebrow">UMA PLATAFORMA, NOVAS POSSIBILIDADES</div><h2>Construído para conectar e crescer</h2></div><div className="feature-grid"><div className="feature"><Building2/><h3>Empresas</h3><p>Cadastre sua empresa e apresente seus serviços após aprovação.</p></div><div className="feature"><Users/><h3>Pessoas</h3><p>Crie sua conta e encontre empresas disponíveis na plataforma.</p></div><div className="feature"><ShieldCheck/><h3>Confiança</h3><p>Publicações passam por análise administrativa.</p></div></div></section></>}/>
    <Route path="/entrar" element={session?<Navigate to="/"/>:<Auth mode="login" onAuth={setSession}/>}/>
    <Route path="/cadastro" element={session?<Navigate to="/"/>:<Auth mode="cadastro" onAuth={setSession}/>}/>
    <Route path="*" element={<Navigate to="/" replace/>}/>
  </Routes>{!isSupabaseConfigured&&<div className="config-banner"><CircleHelp size={17}/> Prévia visual: configure as variáveis do Supabase para ativar login e banco de dados.</div>}</Shell>;
}