-- Crescimento Exponencial: esquema inicial seguro.
-- Execute uma vez no Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.user_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('admin')),
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = (select auth.uid()) and role = 'admin'
  );
$$;

revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (length(trim(name)) > 0),
  description text,
  category text,
  phone text,
  email text,
  address text,
  city text,
  state text,
  website text,
  logo_url text,
  status text not null default 'pending'
    check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists companies_owner_id_idx on public.companies(owner_id);
create index if not exists companies_status_idx on public.companies(status);

create or replace function public.set_updated_at()
returns trigger language plpgsql set search_path = ''
as $$ begin new.updated_at = now(); return new; end; $$;

drop trigger if exists companies_set_updated_at on public.companies;
create trigger companies_set_updated_at before update on public.companies
for each row execute function public.set_updated_at();

alter table public.user_roles enable row level security;
alter table public.companies enable row level security;

drop policy if exists "Users read own role or admins read all" on public.user_roles;
create policy "Users read own role or admins read all" on public.user_roles
for select to authenticated
using (user_id = (select auth.uid()) or (select public.is_admin()));

drop policy if exists "Authenticated read approved or own companies" on public.companies;
create policy "Authenticated read approved or own companies" on public.companies
for select to authenticated
using (status = 'approved' or owner_id = (select auth.uid()) or (select public.is_admin()));

drop policy if exists "Users submit own pending companies" on public.companies;
create policy "Users submit own pending companies" on public.companies
for insert to authenticated
with check (owner_id = (select auth.uid()) and status = 'pending');

drop policy if exists "Owners update own pending companies" on public.companies;
create policy "Owners update own pending companies" on public.companies
for update to authenticated
using (owner_id = (select auth.uid()) and status = 'pending')
with check (owner_id = (select auth.uid()) and status = 'pending');

drop policy if exists "Admins manage companies" on public.companies;
create policy "Admins manage companies" on public.companies
for all to authenticated
using ((select public.is_admin()))
with check ((select public.is_admin()));

grant usage on schema public to authenticated;
grant select on public.user_roles to authenticated;
grant select, insert, update on public.companies to authenticated;

-- Depois de criar sua conta no app, substitua o e-mail e execute
-- este bloco separadamente para conceder acesso de administrador:
-- insert into public.user_roles(user_id, role)
-- select id, 'admin' from auth.users where email = 'SEU_EMAIL'
-- on conflict (user_id) do update set role = excluded.role;
